ELEVN (formerly FPL Analyst)

NEW IN v3.80
- Live: a day with only one match shows it centred.
- Home: free transfers show an Estimated/Confirmed tag and 'extra ones cost 4 pts each'.

NEW IN v3.79 (design review)
- Home: on phones "Do this now" comes straight after your three numbers; the banner is slimmer; an all-clear deadline check is one line instead of a card. Cards size to their content.
- Home: the deadline is shown once (top bar); "Projected" says what it is (best 11 + advised captain) and also shows your lineup as it is set in FPL, so it matches My Team.
- Home: transfer and captain rows no longer cut off the points; captain "chance of 10+" is steadier (5,000 simulations).
- Home cards share one header style; colour is kept for meaning (alerts red, all clear green, actions green edge).
- My Team: the points slider now leads with the advice (e.g. "1 transfer") and shows the slider's maximum only at its far end. Tools and the gameweek switcher share one row, and player names on the pitch stay readable however small it scales.
- Phones: once a team is loaded the Team ID box folds into a person button in the top bar (tap it to change team).
- Live: matches in two columns on wide screens.
- New Daylight theme (Settings > Theme) for bright rooms.

NEW IN v3.78
- Tune-up now reads the accuracy lab's corrections (projected vs real points by position, measured on the teams the lab tracks). They are shown under Fixtures > Accuracy > Tune-up and are applied only after the lab confirms them on a scored gameweek, and only while Tune-up is on. The phone's own weekly learning then covers only the gameweeks the lab has not measured, so no week is corrected twice.

NEW IN v3.77 (changes driven by the accuracy lab's GW11 results)
- Projections: a player's chance of starting now also counts how many of his team's last 5 matches he started and played 60+ minutes, so players who rotate or split minutes are projected lower. GW11 showed rotating defenders and forwards projected too high.
- Projections: bookmaker odds no longer feed the numbers. They are still shown next to matches as context. In the lab, adding them scored worse on points, transfers and captaincy.
- Do this now: the top transfer is highlighted as the top move. Transfers were the app's strongest advice in GW11.
- Captain: when two or three options are projected within about 10% of each other, they are shown together as a close call with each one's chance of 10+ points.
- Live: when FotMob stops answering, scorers and assists come from the Premier League match centre before ESPN (ESPN has no assists).

NEW IN v3.76
- Player stats, Last 5 GWs: asks the Premier League feed for a much smaller fixture list (the full-season list was timing out with HTTP 504). If that feed is still down, the table fills from FPL's own numbers (apps, minutes, goals, expected stats) and says which part is missing, instead of an error.

NEW IN v3.75
- Player stats, Last 5 GWs: when FPL or the Premier League feed is busy (HTTP 504 on matchdays) Elevn now tries again automatically, and if it still fails it shows the last stats that loaded instead of an error.
- Downloads are named with the version (Elevn-Chrome-v3-75.zip) so a Mac keeps the .zip ending.

NEW IN v3.74
- FotMob is now the main live source: live clock (to the second), scorers, half-time/full-time and announced added time come from it first. ESPN and the Premier League match centre are backups.
- Pitch: the "Illustrated player" art style is removed (it looked odd on some screens); anyone on it now sees the FPL kits.

NEW IN v3.73
- Update button (arrow icon at the top): checks GitHub now. If a newer version exists: Download, unzip over this folder, then press "Reload Elevn" (no need to open chrome://extensions). A green dot on the button means an update is waiting.
- My Team opens on the live gameweek while its points are still being calculated, like FPL's Points page. Arrow right to plan the next one.
- Captain: the projection alone decides. Ownership, captaincy share and EO are shown as "crowd lens" context only. Settings > How the numbers are built explains the three layers.

NEW IN v3.72
- Live clock: the added time announced by the referee shows as a red badge next to the minutes (e.g. 90+2:31 +9). The match info shows the announced figure too.
- Player profile: captaincy line (share of the top 10k, how many teams in your league, and whether he's your captain).

NEW IN v3.71
- Fixed: the Egypt banner was broken by the new flag animation. The banner photo now waves gently.
- Live > Ownership & threats: new Captains list. For each popular captain: share in the top 10k (a sample of 100 managers, counted once per gameweek), triple captains, and how many teams in your league captain him (e.g. Haaland 90% top 10k, 17 of 22 in your league).
- Live > My players: gold live-bonus badge in the Bonus column.
- Home "GW vs last GW" card shows the live points during a gameweek.

NEW IN v3.70
- Live bonus points: a gold +1/+2/+3 badge on the player's points tag (My Team and the live matches list) until FPL confirms the bonus. The live total says how much bonus it includes.
- Live gameweek points refresh every minute in My Team.
- Arabic channel names removed (beIN SPORTS number only).

NEW IN v3.69
- beIN SPORTS channels on their own line under the stadium.
- My Team, past and live gameweeks: the "Points per player" table is no longer squeezed off the side on desktop Chrome.
- Live gameweek points add up from your players as matches are played. New points panel and FPL-style player point tags (gold / green / grey), with the fixture and kick-off for players who haven't played yet.
- Country flags in player profiles now wave.
- Your players under each club in the matches list: equal-size chips, evenly spaced, no overlap.

NEW IN v3.68
- Each match shows its beIN SPORTS channel number (e.g. beIN SPORTS 1, 5). The match details also list 4K, English and TOD.

NEW IN v3.67
- Live clock keeps running into stoppage time (90+3:12) and the match info shows the added minutes.
- Match events are listed newest first. An animated GOAL! block appears on the match when a goal goes in.
- Tap any player name in the live matches (scorers, events, your players) to open his profile. beIN SPORTS is shown beside the stadium.

NEW IN v3.66
- Fixed: on phones the match statistics were cut off on the right (the away team's numbers were hidden).

NEW IN v3.65
- Live matches: the clock counts minutes and seconds (45+2:13 in stoppage time), HT and FT.
- Scorers show their goal minute (Muniz 16').
- Tap a match to open its details: date, stadium, attendance, an events timeline (goals with assists, cards, substitutions) and match statistics (possession, shots, corners, fouls, cards, saves, passes). Upcoming matches show a countdown.
- Each card shows the stadium, and a countdown on match day.
- The "2 yours" bubble is replaced by a small count badge next to the club name.

NEW IN v3.64
- Chrome: a desktop notification and a "NEW" badge on the Elevn toolbar icon when a new version is out, checked twice a day even when the FPL site is closed. Click the notification to download.

NEW IN v3.63
- Live matches show HT at half-time and FT at full time (they kept showing the last minute, e.g. 45'+3').
- Half-time and full-time alerts for matches with your players, with your players' points so far (also on Android with the app closed).

NEW IN v3.62
- Kick-off alerts for matches with your players, and an alert for every Premier League goal (both On/Off in Settings).
- Android: with the app closed, the phone now checks the fast live feed every 20 s, so goal and kick-off alerts arrive before FPL has them.

NEW IN v3.61
- Free bookmaker odds on every device, automatically: one bookmaker's win, draw and goals prices are blended into the projections with no key. Your own odds key (many bookmakers) is still used where saved. On/off in Settings.

NEW IN v3.60
- Same numbers on every device: the model calibration and the fixture-difficulty choice are now worked out from FPL data alone, automatically once per finished gameweek, instead of depending on what each phone or computer had saved before.

NEW IN v3.59
- Update banner: Elevn checks once a day for a new version (github.com/Ragxonal/elevn) and offers the right download for your device. The iPhone script now updates itself.
- Fixed: the header showed v3.55 since v3.55.

NEW IN v3.58
- All live sources now shown as "Live source 1/2/3".

NEW IN v3.57
- Live source names hidden in the app; the status line shows how many live sources are in use.

NEW IN v3.56
- A third free live source added to the fast feed: live scores every 10 s, goals, assists, cards and substitutions when its score changes (otherwise every minute). The status line now says which source showed each new goal first. Its own On/Off switch in Settings.

NEW IN v3.55
- Fast live feed (free, no key): during matches Elevn also reads a free live scoreboard (every 10 s) and a second live source with player events (every 20 s). Goals, assists, cards and conceded goals that FPL hasn't counted yet are added straight away, marked ⚡, with an instant goal alert. When FPL catches up its own numbers take over. On/off in Settings.

NEW IN v3.54
- Bookmaker odds (optional): add your free key from the-odds-api.com in Settings. Match-result and over/under 2.5 goals odds become expected goals and clean-sheet chances, blended 50/50 with the model for matches that have prices. Shown under upcoming matches in Live. The key stays on the device.
- The Display sheet is now called Settings.

NEW IN v3.53
- Live matches: your players listed under their own club with a count per side, with player photos.
- Live tables use player photos.
- My Team: shirts 10% bigger, quick-action bubble 30% smaller; "Do this now" is the first tab; the Chips and Do-this-now panels scroll inside instead of stretching the page.
- Head to head: position badge sits next to the photo.
- Player stats and Market: one scrolling list, no Next buttons. Stats filter renamed DefCon and labelled Stats / Position.
- Home: Projected, Bank and Free transfers centred in the app's display font.

NEW IN v3.52
- News: a surname on its own (e.g. "Stroud") only counts when the story names his club, uses football words, or he is a widely owned FPL player. Stops other sports' stories slipping in.

NEW IN v3.51
- News shows only stories about Premier League players. Women's football, youth teams, other leagues, other sports and international match reports are left out (international fitness news, like a player withdrawing injured, stays).
- Phones: Market and Head to Head lists scroll inside the page instead of showing a few players at a time.

NEW IN v3.50
- Smarter injury news: good news (scores, starts, back in training) outweighs a single warning word.
- One headline alone only shows under "Check the news". Captain or line-up changes need FPL's flag, two different sources, or clear words like "ruled out".
- A worry from before his last match is dropped if he then played 60+ minutes.
- Captain switch suggestions show both projections.

NEW IN v3.49
- News fix: "injury-time winner" and "stoppage-time goal" no longer flag a player as injured.

NEW IN v3.48
- New name and logo: Elevn. Eleven dots in formation make an upward arrow; the gold dot is the goalkeeper.
- Your saved team IDs, settings and plans carry over.

NEW IN v3.47
- Wildcard / Free Hit builder now prices every player at today's price, so the squad always fits your FPL budget (even if you remove and re-add a player you already own).
- The builder lists kept players whose selling price is lower than today's price.

Elevn - Chrome extension

NEW IN v3.46
- Points slider: when the transfers path needs 12+ points of hits, it shows what a Wildcard (or Free Hit) would score with no hits and opens the builder in one tap.
- Points slider: chip steps show what each chip adds now against its best week; flagged players in the line-up (or on a Bench Boost bench) are called out.
- Wildcard builder: bench places go to the cheapest players who actually play (no more 0.1-pt fillers). The player card calls a deliberate filler 'Bench filler' instead of 'consider selling'.

NEW IN v3.45 (new prediction model)
- Team strength fitted to this season's results (Poisson attack and defence ratings, recent matches count more).
- Player points built from chance of 60+ minutes, xG and xA per 90 (pulled toward the position average), clean-sheet and goals-conceded odds per fixture, saves, defensive contribution and bonus.
- The model learns from its own misses: every run stores the gameweek's projections, and once played, each position is corrected (gently, at most 15%).
- Points slider uses an exact optimiser (integer programming): the true best squad for each number of transfers, budget and club limits included. 1 GW or 5 GWs ahead. Adds Triple Captain / Bench Boost steps when you still have them.
- Monte Carlo: the gameweek is played 2,500 times to show the likely range and the ceiling (1 week in 10).
- Built-in solver: javascript-lp-solver 1.0.3 (public domain, Unlicense).

NEW IN v3.44
- Themes (Display settings, gear button): Matchday (default: the poster look in softer purple and green), Midnight (calm navy) and Pitch (dark green).
- Larger, brighter text: 15 px base, 14 px in cards, lighter grey for secondary text.
- My Team: Points slider. Slide from your team as it is to the most projected points for the gameweek; each step adds the transfer worth most. Shows hits and the best net position.

NEW IN v3.43
- Calmer 'Midnight' theme: slate navy instead of black, softer green and violet, no glows. One text font (Inter) and one heading font (Barlow, upright), with a fixed size scale and three weights.
- News covers every Premier League player: each story is tagged with every player it names, a search box finds any player or club, and stories are newest first (not your squad first).
- Fixed: 'Bruno Fernandes' stories were tagged as Mateus Fernandes (Spurs).
- Player stats and Market: tick several players, show only them, or compare them in Head to head.

NEW IN v3.42 (new theme)
- New look inspired by FPL tips posters: near-black background with Premier League purple glow and neon green, heavy italic headings, and coloured header bars on Home cards (alerts red, actions green, leagues purple, news blue).
- The profile picture on the Home banner is the Premier League lion, with the manager's flag in its corner.
- The country flag is removed from the top bar; it shows only in the Home banner.

NEW IN v3.41 (new layout)
- Computer screens: main sections move to a slim icon bar on the left; each section's pages show as underlined tabs above the page.
- Home opens with a team banner: the manager's silk flag as artwork, a round team badge with a small flag in its corner, team name, manager, country, rank, points and the deadline countdown.
- Section titles are upper-case. Phones keep the bottom navigation bar.

NEW IN v3.40
- Flags: Egypt uses the real silk flag photo; every other flag gets the same silk folds laid over its own colours (player page and top bar).
- Player stats: the column buttons now work everywhere. Desktop: Attack / Expected / Defence. Phones: Goals / Shots / xG / Per 90 / Defence.
- Player stats: new Defence columns: CBI, tackles, recoveries, defensive contribution (DC), DC per 90, DC+2 (matches that earned FPL's +2 defensive bonus), clean sheets and saves. Also in the Last 5 GWs view.

NEW IN v3.39
- Fixed: the saved-teams menu next to the Team ID box opens again, so you can save friends' IDs and switch between them.

NEW IN v3.38
- Fixed: on phones the Team ID box was hidden under the tabs (the top bar was being squeezed). It always shows now.

NEW IN v3.37
- Player stats: every column fits on one screen (no sideways or vertical scroll). On phones, pick Goals / Shots / Big ch. / xG / Per 90.
- Head to head redesigned: player cards (leader highlighted) and comparison bars on every row.
- News: the filtered stories sit right under the filters; 'Affecting your team' follows them.
- Season so far: bars show points above or below each gameweek's average; your overall rank has its own gold line underneath.
- Flags: silky waving flags. The real flag sits in the middle with its edge colours extended across the banner (player page and the app's top bar).

NEW IN v3.36
- Player stats now works in the Android app and the iPhone script too (not only Chrome).
- Player stats and Market list every player (all 672), one screen at a time with Prev / Next: no vertical scrolling.
- Player photos use a rounded-rectangle crop; Head to head shows player faces instead of shirts.
- The manager's country flag sits in the app's top bar with a glassy, fading look. Player page flags fit the header exactly.
- Market: price columns renamed (Change this GW, Change this season, Next change). Next change shows 'Rise due' / 'Drop due' instead of percentages over 100%, and 'tonight' shows the local time of FPL's daily price update (about 01:30 UK time).

NEW IN v3.35
- Player Stats now compares All Season, Last 5 GWs and Last 3 GWs.
- Recent windows end at the latest completed gameweek and include blank gameweeks.
- Recent performance metrics are aggregated from the Premier League match stats feed.

INSTALL (one time)
1. Unzip this folder somewhere you'll keep it (e.g. Documents/Elevn).
2. In Chrome, go to chrome://extensions
3. Turn on "Developer mode" (top right).
4. Click "Load unpacked" and choose the unzipped Elevn folder.
5. Optional: click the puzzle icon in the toolbar and pin Elevn.

USE (every gameweek)
- Open fantasy.premierleague.com and click the green "Elevn" button (bottom right),
  or click the extension icon in the toolbar.
- Your team ID is filled in when you're signed in. Type any other ID to analyse a friend or rival.
- Run it again before each deadline: FPL data, the league table and the news are read live every time.

Sources: BBC Sport, Sky Sports, The Guardian, The Independent, Daily Mirror, Evening Standard, talkSPORT, Football365, Fantasy Football Scout, Google News searches (team news, press
conferences, FIFA international duty, FPL, gameweek leaks, predicted and leaked line-ups,
training reports, Fabrizio Romano, David Ornstein) and Reddit r/FantasyPL and r/PremierLeague, read directly by the extension (rss2json is the backup).
Only feed addresses are ever sent to rss2json, never your team details.

UPDATING FROM AN OLDER VERSION
1. In chrome://extensions, click "Remove" on every Elevn card (so only one copy remains).
2. Delete your old Elevn folder, then unzip this new zip and load it with "Load unpacked".
3. Reload the FPL page (F5). The panel header shows the version, e.g. "Elevn v3.19".

NEW IN v3.32
- Fixtures: new Player stats tab with all FPL players, search, position filters and sortable columns for team, cost, appearances, minutes, goal splits, shot splits, minutes per goal/shot and big chances.
- Player identity, club and price come from FPL; season metrics are joined by Opta player code from the Premier League stats feed. Big Chances Total is scored plus missed.
- The extension now asks Chrome for permission to contact the Premier League stats host when updating/loading this version.

NEW IN v3.31
- My Team: the Targets / Differentials / Chips tabs fill the whole bar (no empty slot on the right).

NEW IN v3.30
- Home: the manager's country flag waves softly behind the team name in the header card, semi-transparent with shaded folds, fading out. Nothing moves.
- My Team, Chips: four small equal chip blocks sitting straight in the panel (no inner box).

NEW IN v3.29
- Dragging fixed: the dragged player now stays under your finger and the page no longer scrolls during a drag.
- My Team (wide screens): Targets, Differentials and Chips fill the panel beside the pitch; extra cards sit behind 'Show N more'.
- Player page: the national flag fills the header, sharp and unblurred.
- News: filters wrap on phones, show how many stories each has, and say so when a filter is empty.

NEW IN v3.28
- Live deadline countdown (days, hours, minutes, seconds) in the header and on the Home team card.
- My Team: pitch and bench always fit on one screen, so dragging players needs no scrolling.
- Targets: compact transfer cards; the panel no longer has its own scroll bar.
- Flags show the whole flag (every stripe) behind the player page header and Home team card.

NEW IN v3.27
- Flags fill the whole Home team card and the whole player page header, softly blurred behind the text.
- Home on large screens: every block grows to fit its content; no inner scroll bars and nothing cut off.

NEW IN v3.23
- Home: the team banner shows the manager's country flag (from FPL).
- Flags are sharp vector images, kept at their true shape (no stretching).
- The Home button shows Home for the team you are viewing; it no longer jumps to your saved ID. 'Back to my team' still does.

NEW IN v3.22
- Tapping a player on the pitch pops out a small bar of 5 actions (Swap, Captain, Vice, Sell, Profile) instead of a sheet.
- Live: the tab row no longer makes the page slide sideways on phones.
- Player page: the club shirt over the photo is gone (it still shows when there is no photo).

NEW IN v3.21
- The player page header shows the player's national flag as its background banner.
- The player page names his country next to his full name.

NEW IN v3.19 (design review fixes)
- Sub-tabs (Pitch/List, Fixtures pages) are one scrolling row that stays at the top on phones; one tab style everywhere.
- Readable text: nothing under 10 px; larger touch targets (36-44 px) for tools, arrows and pickers.
- Home: Do this now shows "Thomas -> Araujo +21.6 pts" in full and no longer repeats the alert card;
  Leagues & cups shows 5 with "Show all".
- Shorter one-line page intros; Market and Accuracy use plain titles; Market search has its own row.
- Wide tables keep the first column in place and fade at the edge when there is more to scroll.
- Clear error messages (e.g. "No FPL team with ID ..."), alert headlines without underlines, Bench label visible.
- Tablet: countdown on the Team ID row. Live: "Next up" strip between gameweeks.
- Android: follows your phone's font size up to 115%.

NEW IN v3.18
- News in Chrome is now read by the extension itself (its background can read the news sites listed in its
  permissions), so it gets the same stories as the Android app. rss2json is only used if a site can't be read.
  When you reload the extension, Chrome may ask to allow access to these news sites: allow it.
- iPhone (Userscripts app): reads news sites directly too; allow the requests if Userscripts asks.

NEW IN v3.17
- Deadline alerts: fewer false alarms. Only the words right next to a player's name count; "doubt" must be about
  fitness; list posts (fixture calendars, rate-my-team, price-change threads) never raise alerts; a single
  community post is not enough on its own (needs a news story or a second post).

NEW IN v3.16
- My Team: small, even tool buttons (Undo icon, Best 11 players, Reset, Clear plan) above the gameweek bar, which now
  sits right above the pitch. Player size fits the screen automatically; the Size and Card info controls are gone
  and every player card shows full FPL data (price and next 3 fixtures).
- Pitch figures (GW pts, 5 GWs, Bank, Transfers, formation) in one compact row that always fits.
- Side tabs: Targets, Differentials, Chips (Auto plan and Captain removed). Smaller Targets cards.
- Chips: one box with all four chips; red = not available this week (used, or not in this half of the season).
- List: player photos and a legend explaining each verdict.

NEW IN v3.15
- Faster start: opens instantly with the last saved data, then updates quietly in the background.
- Move your plan between devices: Display settings (gear) > Copy my code / Paste a code.
- Price predictions: Market > "Likely to rise" / "Likely to fall" with % progress and when (tonight, tomorrow).
  Gets more accurate the more often you open the app (it records the transfer trend every 2 hours).
- Captain tab in the team planner: most points, safe pick and differential, with ownership overall and in your league,
  and a recommendation based on your league position.
- Live > Rival watch: the managers just above and below you, their transfers, captain, chip, the players they have
  that you don't, and what happens if those players score.
- Fixtures > Accuracy: your own team, projected vs actual each week, and a per-position tune-up of the projections.
- News: fewer, more relevant feeds.
- Android app only: deadline reminders 24 h and 2 h before each deadline; goal, assist and red-card alerts with the app
  closed (every minute after you leave the app during matches, otherwise every 15 minutes); the app reads news feeds
  itself, with rss2json as the backup. Both can be switched off in Display settings.

NEW IN v3.14
- Player names everywhere: badge and name on one line, same size, no dotted underline.
- Live (My players, Ownership & threats) and the replacement list show club kits instead of badges.
- Team planner (phone): Projected / Next 5 / Bank / Transfers sit in one row above the players instead of covering them.
- Tapping a player: compact sheet with his next 3 matches and projected points, a quick tip, and one row of
  actions (Swap, Captain, Vice, Sell, Profile).
- New player card (from anywhere): photo with club kit, price and signal, next GW / next 3 / rating / owned,
  points chart, rating radar and key stats on one screen; details folded underneath. Tap outside to close.
- Market lists all 672 Premier League players.
- Head to head list: price and club no longer overlap.
- Android app: ignores the phone's font-size setting so screens fit; no scrollbars.

NEW IN v3.13
- Mini-league tables show your real position in big leagues (e.g. 4,086) below the top 25, instead of 26th.
- Top 5 in every league table get a crown, medals and badges (👑 🥈 🥉 🚀 🔥) with coloured rows.
- News: only Premier League clubs and players, only the last 48 hours, newest first. New exclusive sources
  and an "Exclusives" filter. Filters and a Source picker now sit at the top of the News page.
- Head to head: club kits next to every player name.
- Player names: the club icon is sized to the text everywhere (Deadline check, Do this now and all other sections).
- Team planner: drag a player by the jersey or the box; the page scrolls while you drag down to the bench,
  and movement is smoother on phones.

NEW IN v3.12
- My team and saved friends: the people button next to Team ID lists your own team (your Home team)
  and saved friends' and rivals' IDs. Open a team, then "Save" it; "Make this my team" changes your Home team.
  The Home tab always brings you back to your own team.
- Home: Latest news is a short list of 3-4 headlines.
- Live > Matches: status and dates sit at the top centre of each match; every match shows how many of your
  players are in it (with their points), and the header shows how many of your 15 are playing that week.
- Live > Mini-league: new league and cup picker with type badges and your rank; opens on a league that has a table.
- Fixtures > Pairs: pick Goalkeepers or Defenders; each pair shows the club to start each week, the two cheapest
  nailed starters and their total cost, and marks clubs you already own.
- Fixtures > Head to head: phone friendly. Chosen players sit at the top; the comparison puts players side by side
  with week-by-week projections and fixtures (or season stats), best values marked in green.

NEW IN v3.11
- Home: one even 3 x 2 grid that always fits the screen (Deadline check, Do this now, Leagues & cups,
  this week vs last, Season so far, Latest news). Smaller text; long cards scroll inside themselves.
- Leagues & cups (Home, under the Team ID box): every league, head-to-head league and cup with your rank.
  Tap one to open its live table in Live > Mini-league, which now also handles head-to-head leagues
  (with your match this week) and cups (ties, results and the live score against your opponent).
  Cups that FPL hasn't drawn yet are listed as "Not started".
- Fixtures > Market: transfers in/out, net transfers and price changes (gameweek and season) for every player,
  with search, position filter, Most transferred in/out, Biggest risers/fallers and sortable columns.
- Fixtures > Head to head: compare up to 10 players. Player list on the left (search, position, rating,
  GW or 6-GW projection); week-by-week projections with fixtures, or season stats, on the right.
  "Compare these" loads the transfers you planned.
- Fixtures > Accuracy: the "How accurate are the projections" test moved here from Home.
- Player page: in the transfer planner (and in Market / Head to head) a player name opens a full page:
  price changes, rating radar, next GW / next 3 / ownership / season, last 3 + next 6 points chart,
  set pieces, season stats, transfer signal, similar players, news and past seasons.
- Official FPL kits on the pitch, in transfer cards and on player profiles (Card info > Player art lets
  you switch back to the drawn shirt or illustrated player).
- Planner: the formation is shown on the pitch, and the Undo / tools row no longer covers the gameweek arrows.

GOAL ALERTS
While matches are live and the analyst panel is open, it checks FPL every 15 seconds and alerts you
to goals, assists, cards, clean sheets lost and bonus for your players: a card in the panel and a
desktop notification. Chrome may ask once to allow notifications from the extension. Turn alerts
off with the "Goal alerts" button in the Live section.

RESIZABLE PLANNER (new in v3.10)
- Size slider (Planner toolbar): scales every player card together, so jersey, name, price and fixture strip keep the same proportions. Bench players are always drawn at 88% of the starters.
- Fit button: sizes the players automatically so the widest line fills the pitch evenly. This is the default.
- Drag the thin bar between the pitch and the side panel to give either one more room. Double-click it (or press Home while it is focused) to reset; the arrow keys nudge it.
- Lines of players are spread evenly across the pitch, and the four lines are spaced evenly from top to bottom.
- Your size and split position are remembered.

ADDED IN v3.10 (the v3.10 design plus the v3.10 features)
- Live: the first tab is "Matches", a matchweek view with prev/next arrows, fixtures grouped by day, FT or live minute, score and scorers, and "N yours" on matches with your players.
- Fixtures: new "Head to head" tab (sell vs buy for your planned transfers). The planner links to it.
- Player buttons ("Bring in", etc.) now confirm the move with a tick and a message with an Open planner button.
- Green up / red down arrows shown under Projected and Next 5 GWs on the pitch, and under each figure in the history strip.

PLAYER CARD INFO (new in v3.10, calmer in v3.10)
- Planner toolbar > "Card info" opens a bar under the toolbar (it pushes the pitch down, it never covers it) with a live preview card. Choose what each player shows. Quick styles: Full, Compact (price + next fixture), Minimal (name only).
- Or switch individually: price, number of next fixtures (off / 1 / 2 / 3), penalty and set-piece badges, "in form" star, club code on the shirt.
- Name, captain / vice badges and injury warnings always stay. Your choice is remembered.

NEW IN v3.10
- Home top strip redesigned: five clearly labelled figures (Total points, Overall rank with places moved, Projected GW with your captain, Bank, Free transfers). Free transfers say whether the number is confirmed by FPL or estimated.
- Live > Mini-league: click any team to open its account. The Team ID box fills in automatically and that team is analysed. A "Back to my team" bar appears while you are viewing someone else.

PAST SEASONS (v3.10)
The projection model also uses 2024/25 and 2023/24 season totals from the public FPL data archive
(github.com/vaastav/Fantasy-Premier-League). They are downloaded once and kept on this browser.
