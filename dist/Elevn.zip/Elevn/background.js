chrome.action.onClicked.addListener(async (tab) => {
  if (tab.url && tab.url.startsWith('https://fantasy.premierleague.com')) {
    try { await chrome.tabs.sendMessage(tab.id, { type: 'fpl-analyst-toggle' }); }
    catch (e) { await chrome.tabs.reload(tab.id); }
  } else {
    chrome.tabs.create({ url: 'https://fantasy.premierleague.com/my-team' });
  }
});

// Desktop notifications for goal alerts sent by the analyst panel
chrome.runtime.onMessage.addListener((m) => {
  if (m && m.type === 'fpl-notify') {
    chrome.notifications.create({ type: 'basic', iconUrl: 'icons/128.png', title: String(m.title || 'Elevn').slice(0, 120), message: String(m.body || '').slice(0, 240), priority: 2 });
  }
});

// v3.18: read news feeds here. The panel runs inside the FPL page, where browser security (CORS) blocks reading
// other sites; the extension's background may read the sites listed in host_permissions in the manifest.
const FEED_OK = /^https:\/\/(feeds\.bbci\.co\.uk|www\.skysports\.com|www\.theguardian\.com|www\.independent\.co\.uk|www\.mirror\.co\.uk|talksport\.com|www\.football365\.com|www\.fantasyfootballscout\.co\.uk|news\.google\.com|www\.reddit\.com|old\.reddit\.com|api\.the-odds-api\.com|site\.api\.espn\.com|www\.fotmob\.com|raw\.githubusercontent\.com)\//;
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || m.type !== 'fpl-fetch') return;
  if (!FEED_OK.test(String(m.url))) { reply({ ok: false, text: 'host not allowed' }); return; }
  const ctl = new AbortController(); const tm = setTimeout(() => ctl.abort(), 12000);
  fetch(m.url, { signal: ctl.signal, credentials: 'omit', headers: { Accept: 'application/rss+xml, application/atom+xml, application/xml, text/xml, application/json, */*' } })
    .then((r) => (r.ok ? r.text() : Promise.reject(new Error('HTTP ' + r.status))))
    .then((text) => reply({ ok: true, text }))
    .catch((e) => reply({ ok: false, text: String(e && e.message || e) }))
    .finally(() => clearTimeout(tm));
  return true; // answer comes later
});

// v3.32: retrieve season player metrics from the Premier League stats feed.
// Only the fixed PL competition and metric list below are permitted; callers
// cannot pass arbitrary URLs through this message.
const PL_STAT_METRICS = {
  apps: 'appearances', mins: 'mins_played', goals: 'goals',
  goalsIn: 'att_ibox_goal', goalsOut: 'att_obox_goal', goalsHead: 'att_hd_goal',
  shots: 'total_scoring_att', shotsIn: 'attempts_ibox', shotsOut: 'attempts_obox',
  shotsHead: 'att_hd_total', shotsOn: 'ontarget_scoring_att',
  bigScored: 'big_chance_scored', bigMissed: 'big_chance_missed'
};
const PL_API = 'https://footballapi.pulselive.com/football/';
async function plJson(path) {
  const ctl = new AbortController();
  const timer = setTimeout(() => ctl.abort(), 15000);
  try {
    const res = await fetch(PL_API + path, { signal: ctl.signal, credentials: 'omit', cache: 'no-store', headers: { Accept: 'application/json' } });
    if (!res.ok) throw new Error('HTTP ' + res.status);
    return await res.json();
  } finally { clearTimeout(timer); }
}
async function getPlMetric(seasonId, metric) {
  const qs = new URLSearchParams({ comp: '1', compSeasons: String(seasonId), altIds: 'true', page: '0', pageSize: '1000' });
  const first = await plJson(`stats/ranked/players/${encodeURIComponent(metric)}?${qs}`);
  const s = first.stats || {};
  let rows = s.content || [];
  const pages = Math.min(5, Number(s.pageInfo && s.pageInfo.numPages) || 1);
  for (let page = 1; page < pages; page++) {
    qs.set('page', String(page));
    const next = await plJson(`stats/ranked/players/${encodeURIComponent(metric)}?${qs}`);
    rows = rows.concat(next.stats && next.stats.content || []);
  }
  return rows;
}
async function loadPlPlayerStats() {
  const seasons = await plJson('competitions/1/compseasons?page=0&pageSize=100');
  const season = (seasons.content || [])[0];
  if (!season || !season.id) throw new Error('Could not identify the current Premier League season.');
  const entries = Object.entries(PL_STAT_METRICS), output = {}, errors = [], loaded = [];
  let cursor = 0;
  const worker = async () => {
    while (cursor < entries.length) {
      const [key, metric] = entries[cursor++];
      try {
        const rows = await getPlMetric(season.id, metric);
        for (const row of rows) {
          const code = row && row.owner && row.owner.altIds && row.owner.altIds.opta;
          if (!code) continue;
          if (!output[code]) output[code] = {};
          output[code][key] = Number(row.value) || 0;
          if (row.owner.id) output[code]._plId = Number(row.owner.id);
        }
        loaded.push(key);
      } catch (e) { errors.push({ key, message: String(e && e.message || e) }); }
    }
  };
  await Promise.all(Array.from({ length: 4 }, worker));
  return { seasonId: season.id, seasonLabel: season.label || '', fetchedAt: Date.now(), data: output, loaded, errors };
}

async function loadPlPlayerWindow(m) {
  const fromGw = Number(m.fromGw), toGw = Number(m.toGw);
  if (!Number.isInteger(fromGw) || !Number.isInteger(toGw) || fromGw < 1 || toGw < fromGw || toGw - fromGw > 9) throw new Error('Invalid gameweek range.');
  if (!Array.isArray(m.players) || m.players.length > 700) throw new Error('Invalid player list.');
  const seasons = await plJson('competitions/1/compseasons?page=0&pageSize=100');
  const season = (seasons.content || [])[0];
  if (!season || !season.id) throw new Error('Could not identify the current Premier League season.');
  const qs = new URLSearchParams({ comp: '1', compSeasons: String(season.id), page: '0', pageSize: '1000' });
  const fixtures = await plJson(`fixtures?${qs}`);
  const fixtureRows = Array.isArray(fixtures) ? fixtures : (fixtures.content || []);
  const fixtureIds = fixtureRows.filter((f) => f && f.status === 'C' && Number(f.gameweek && f.gameweek.gameweek) >= fromGw && Number(f.gameweek && f.gameweek.gameweek) <= toGw).map((f) => Number(f.id)).filter(Number.isFinite);
  if (!fixtureIds.length) throw new Error(`No completed Premier League fixtures found for GW${fromGw}–GW${toGw}.`);
  const players = m.players.filter((p) => p && /^p\d+$/.test(String(p.code)) && Number.isInteger(Number(p.playerId)) && Number(p.playerId) > 0);
  const data = {}, errors = [];
  let cursor = 0;
  const worker = async () => {
    while (cursor < players.length) {
      const p = players[cursor++];
      try {
        const path = `stats/player/${Number(p.playerId)}?fixtures=${fixtureIds.join(',')}`;
        const result = await plJson(path);
        const row = {};
        for (const stat of (result.stats || [])) {
          const entry = Object.entries(PL_STAT_METRICS).find(([, name]) => name === stat.name);
          if (entry) row[entry[0]] = Number(stat.value) || 0;
        }
        data[p.code] = row;
      } catch (e) { errors.push(p.code); }
    }
  };
  await Promise.all(Array.from({ length: 6 }, worker));
  return { seasonId: season.id, seasonLabel: season.label || '', fromGw, toGw, fixtureCount: fixtureIds.length, fetchedAt: Date.now(), data, loaded: Object.keys(PL_STAT_METRICS), failedCodes: errors, errors: errors.length ? [{ message: `${errors.length} players could not be refreshed.` }] : [] };
}
chrome.runtime.onMessage.addListener((m, sender, reply) => {
  if (!m || !['fpl-pl-player-stats', 'fpl-pl-player-window-stats'].includes(m.type)) return;
  if (!sender.url || !/^https:\/\/fantasy\.premierleague\.com\//.test(sender.url)) { reply({ ok: false, error: 'Request origin not allowed.' }); return; }
  const task = m.type === 'fpl-pl-player-stats' ? loadPlPlayerStats() : loadPlPlayerWindow(m);
  task.then((data) => reply({ ok: true, data })).catch((e) => reply({ ok: false, error: String(e && e.message || e) }));
  return true;
});
